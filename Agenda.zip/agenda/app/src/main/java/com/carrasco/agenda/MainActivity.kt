package com.carrasco.agenda

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.carrasco.agenda.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private val contacts = (1..100).map {
        Contact("Nombre $it", "Telefono $it","Email $it","https://loremflickr.com/240/320/face?lock=$it")
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.contact.adapter = ContactAdapter(contacts)
    }
}